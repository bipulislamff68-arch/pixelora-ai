# Pixelora – GitHub Pages (website) + Render (backend)

```
frontend/index.html   -> goes into your EXISTING GitHub Pages repository (replaces the old index.html)
backend/              -> goes into a NEW GitHub repository, deployed on Render
  server.js, package.json, .env.example
```
Your github.io address does not change.

## Step 1 – Deploy the backend on Render
1. Get an API key: sign up at https://www.remove.bg/api and copy your key. (Check their current free limits; the free tier may return lower-resolution results.)
2. On GitHub create a NEW repository, e.g. `pixelora-backend`. Upload `server.js` and `package.json` from the `backend` folder to its top level. Do NOT upload any file containing your real key.
3. On https://render.com create an account, then New > Web Service, and connect `pixelora-backend`.
4. Settings: Runtime = Node, Build Command = `npm install`, Start Command = `npm start`.
5. Open Environment and add two variables:
   - `REMOVEBG_API_KEY` = your remove.bg key
   - `ALLOWED_ORIGIN` = your GitHub Pages ORIGIN, i.e. only scheme + host: `https://your-username.github.io`
     (not `https://your-username.github.io/repo-name/`, no trailing slash). If you use a custom domain, use that instead. Separate several origins with commas.
6. Deploy. Copy your Render URL (e.g. `https://pixelora-backend.onrender.com`). Opening it should show "Pixelora API is running."

## Step 2 – Connect the website
1. Open `frontend/index.html`, find this line and put in your Render URL (no trailing slash):
   `const API_BASE='https://YOUR-RENDER-APP.onrender.com';`
2. Upload this `index.html` to your existing GitHub Pages repository (replace the old file). Wait ~1 minute, then open your github.io site (hard refresh).

## Notes
- The API key lives only in Render's Environment. Never put it in index.html or GitHub.
- Render free plan sleeps when idle: the first request after a break can take up to ~1 minute. Its disk resets on restart, so the example cut-outs may be regenerated (uses remove.bg credits). To avoid that, put your own transparent PNGs in an `examples/` folder in your GitHub Pages repo named `products-1-after.png`, `products-2-after.png`, `products-3-after.png`, `portraits-1-after.png` ... `animals-3-after.png`.
- Errors you may see: "backend address is not set" (edit API_BASE), "not allowed to use the server" (ALLOWED_ORIGIN wrong), "Could not reach the AI server" (backend asleep/URL wrong/offline), "API key rejected", "out of credits", "too many requests".

## Not tested yet (please test manually)
Nothing here was run in a browser or against remove.bg. Test: (1) your Render URL opens; (2) upload a photo > Background removal gives a transparent PNG with the scan animations; (3) homepage slider auto-moves and can be dragged on phone and desktop; (4) Products/Portraits/Animals sliders on phone and desktop; (5) wrong key / wrong ALLOWED_ORIGIN show clear errors.
