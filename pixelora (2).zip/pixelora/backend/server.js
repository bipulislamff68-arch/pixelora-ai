/* Pixelora backend (runs on Render): proxies background removal to remove.bg. The API key stays here, never in the browser.
   ALLOWED_ORIGIN = your GitHub Pages origin(s), e.g. https://username.github.io (comma-separated, no path, no trailing slash). */
const express=require('express'),fs=require('fs'),path=require('path');
const KEY=process.env.REMOVEBG_API_KEY,PORT=process.env.PORT||3000,CACHE=path.join(__dirname,'cache');
const app=express();app.disable('x-powered-by');app.set('trust proxy',1);fs.mkdirSync(CACHE,{recursive:true});
const ORIGINS=(process.env.ALLOWED_ORIGIN||'').split(',').map(x=>x.trim().replace(/\/+$/,'')).filter(Boolean);
app.use((req,res,next)=>{const o=req.headers.origin;
  if(o){if(ORIGINS.includes(o)||o===req.protocol+'://'+req.get('host'))res.set({'Access-Control-Allow-Origin':o,'Vary':'Origin','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'86400'});
    else return res.status(403).json({error:'This website is not allowed to use the server.'})}
  if(req.method==='OPTIONS')return res.sendStatus(204);next()});
const hits=new Map();
const limit=max=>(req,res,next)=>{const now=Date.now(),a=(hits.get(req.ip+req.path)||[]).filter(t=>now-t<60000);if(a.length>=max)return res.status(429).json({error:'Too many requests. Please wait a minute and try again.'});a.push(now);hits.set(req.ip+req.path,a);next()};
const fail=(status,error)=>Object.assign(new Error(error),{status,error});
async function removeBg(buf,type){
  if(!KEY)throw fail(500,'The server is missing its REMOVEBG_API_KEY setting.');
  const fd=new FormData();fd.append('image_file',new Blob([buf],{type}),'image');fd.append('size','auto');fd.append('format','png');
  let r;try{r=await fetch('https://api.remove.bg/v1.0/removebg',{method:'POST',headers:{'X-Api-Key':KEY},body:fd,signal:AbortSignal.timeout(90000)})}catch(e){throw fail(504,'The AI service did not respond in time. Please try again.')}
  if(r.ok)return Buffer.from(await r.arrayBuffer());
  let code='';try{code=((await r.json()).errors||[])[0].code||''}catch(_){}
  if(r.status===402)throw fail(502,'The AI service has run out of credits.');
  if(r.status===403)throw fail(502,'The server API key was rejected by the AI service.');
  if(r.status===429)throw fail(503,'The AI service is busy. Please try again shortly.');
  if(code==='unknown_foreground')throw fail(422,'The AI could not find a clear main subject in this image.');
  if(r.status===400)throw fail(400,'This image could not be processed. Try a different JPG, PNG or WebP photo.');
  throw fail(502,'The AI service failed. Please try again.');
}
app.post('/api/remove-background',limit(12),express.raw({type:['image/jpeg','image/png','image/webp'],limit:'13mb'}),async(req,res)=>{
  try{if(!Buffer.isBuffer(req.body)||!req.body.length)throw fail(400,'Please upload a JPG, PNG or WebP image (max 12 MB).');
    const png=await removeBg(req.body,req.headers['content-type'].split(';')[0]);res.set({'Content-Type':'image/png','Cache-Control':'no-store'}).send(png)}
  catch(e){res.status(e.status||500).json({error:e.error||'Background removal failed. Please try again.'})}
});
/* Transparent cut-outs for the Products / Portraits / Animals examples: made once with the same AI, then cached on disk */
const pending=new Map();
app.get('/api/example-cutout',limit(30),async(req,res)=>{
  const id=String(req.query.id||'');if(!/^\d{10,}-[0-9a-f]{12}$/.test(id))return res.status(400).json({error:'Unknown example.'});
  const file=path.join(CACHE,id+'.png');
  try{if(!fs.existsSync(file)){
      if(!pending.has(id))pending.set(id,(async()=>{const r=await fetch('https://images.unsplash.com/photo-'+id+'?auto=format&fit=crop&w=1000&q=80');if(!r.ok)throw fail(502,'Example image unavailable.');
        fs.writeFileSync(file,await removeBg(Buffer.from(await r.arrayBuffer()),'image/jpeg'))})().finally(()=>pending.delete(id)));
      await pending.get(id)}
    res.set('Cache-Control','public, max-age=86400').type('png').sendFile(file)}
  catch(e){res.status(e.status||500).json({error:e.error||'Cut-out failed.'})}
});
app.get('/',(req,res)=>res.type('text').send('Pixelora API is running.'));
app.use((err,req,res,next)=>res.status(err.status===413||err.type==='entity.too.large'?413:500).json({error:err.status===413||err.type==='entity.too.large'?'This image is too large (max 12 MB).':'Server error. Please try again.'}));
app.listen(PORT,()=>console.log('Pixelora running on http://localhost:'+PORT+(KEY?'':'  (WARNING: REMOVEBG_API_KEY is not set)')+(ORIGINS.length?'':'  (WARNING: ALLOWED_ORIGIN is not set)')));
